#include <stdio.h>

int main()
{
    int h[8], r[8], i, p1, p2, p4, pos;

    printf("Enter 4 data bits: ");
    scanf("%d %d %d %d", &h[3], &h[5], &h[6], &h[7]);

    h[1] = h[3] ^ h[5] ^ h[7];
    h[2] = h[3] ^ h[6] ^ h[7];
    h[4] = h[5] ^ h[6] ^ h[7];

    printf("Hamming Code: ");
    for(i = 1; i <= 7; i++)
        printf("%d", h[i]);

    printf("\nEnter received 7 bits: ");
    for(i = 1; i <= 7; i++)
        scanf("%1d", &r[i]);

    p1 = r[1] ^ r[3] ^ r[5] ^ r[7];
    p2 = r[2] ^ r[3] ^ r[6] ^ r[7];
    p4 = r[4] ^ r[5] ^ r[6] ^ r[7];

    pos = p1 + 2*p2 + 4*p4;

    if(pos == 0)
        printf("No error detected\n");
    else
    {
        printf("Error at position %d\n", pos);
        r[pos] = 1 - r[pos];
    }

    printf("Corrected Code: ");
    for(i = 1; i <= 7; i++)
        printf("%d", r[i]);

    return 0;
}